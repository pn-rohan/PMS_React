import React, { useState } from 'react';

const NewRequestModal = ({ onClose, onAdd, projectTeams, etdgTopics }) => {
  const [formData, setFormData] = useState({
    projectTeam: projectTeams[0],
    topics: [],
    fte: 0,
    ew: 0
  });
  const [showTopicDropdown, setShowTopicDropdown] = useState(false);

  const handleTopicAdd = (topic) => {
    if (!formData.topics.includes(topic)) {
      setFormData({ ...formData, topics: [...formData.topics, topic] });
    }
    setShowTopicDropdown(false);
  };

  const handleTopicRemove = (topicToRemove) => {
    setFormData({
      ...formData,
      topics: formData.topics.filter(topic => topic !== topicToRemove)
    });
  };

  const handleSubmit = () => {
    onAdd(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-2xl"
        >
          ×
        </button>

        {/* Modal Title */}
        <h2 className="text-xl font-semibold text-gray-800 mb-6">New Request</h2>

        {/* Form */}
        <div className="space-y-5">
          {/* Field 1: Digital Project/Product Team */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              * 1. DIGITAL PROJECT/PRODUCT TEAM
            </label>
            <select
              value={formData.projectTeam}
              onChange={(e) => setFormData({ ...formData, projectTeam: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {projectTeams.map((team) => (
                <option key={team} value={team}>
                  {team}
                </option>
              ))}
            </select>
          </div>

          {/* Field 2: ETDG Topic */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              * 2. ETDG TOPIC
            </label>
            <div className="relative">
              <div
                className="w-full px-3 py-2 border border-gray-300 rounded-md min-h-[42px] flex flex-wrap gap-2 cursor-pointer"
                onClick={() => setShowTopicDropdown(!showTopicDropdown)}
              >
                {formData.topics.map((topic) => (
                  <span
                    key={topic}
                    className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm flex items-center gap-2"
                  >
                    {topic}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTopicRemove(topic);
                      }}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      ×
                    </button>
                  </span>
                ))}
                {formData.topics.length === 0 && (
                  <span className="text-gray-400">Select topics...</span>
                )}
              </div>
              
              {showTopicDropdown && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-48 overflow-y-auto">
                  {etdgTopics.map((topic) => (
                    <div
                      key={topic}
                      onClick={() => handleTopicAdd(topic)}
                      className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                    >
                      {topic}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Field 3: Resources */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              * 3. HOW MANY RESOURCES ARE YOU ASKING?
            </label>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <label className="text-sm text-gray-600">* FTE</label>
                <button
                  onClick={() => setFormData({ ...formData, fte: Math.max(0, formData.fte - 1) })}
                  className="w-8 h-8 border border-gray-300 rounded-full hover:bg-gray-100"
                >
                  -
                </button>
                <input
                  type="number"
                  value={formData.fte}
                  onChange={(e) => setFormData({ ...formData, fte: parseInt(e.target.value) || 0 })}
                  className="w-16 px-3 py-2 border border-gray-300 rounded-md text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={() => setFormData({ ...formData, fte: formData.fte + 1 })}
                  className="w-8 h-8 border border-gray-300 rounded-full hover:bg-gray-100"
                >
                  +
                </button>
              </div>

              <div className="flex items-center gap-2">
                <label className="text-sm text-gray-600">* EW</label>
                <button
                  onClick={() => setFormData({ ...formData, ew: Math.max(0, formData.ew - 1) })}
                  className="w-8 h-8 border border-gray-300 rounded-full hover:bg-gray-100"
                >
                  -
                </button>
                <input
                  type="number"
                  value={formData.ew}
                  onChange={(e) => setFormData({ ...formData, ew: parseInt(e.target.value) || 0 })}
                  className="w-16 px-3 py-2 border border-gray-300 rounded-md text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={() => setFormData({ ...formData, ew: formData.ew + 1 })}
                  className="w-8 h-8 border border-gray-300 rounded-full hover:bg-gray-100"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-3 mt-8">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition"
          >
            CANCEL
          </button>
          <button
            onClick={handleSubmit}
            className="px-6 py-2 bg-primus-blue text-white rounded-md hover:bg-blue-700 transition"
          >
            ADD
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewRequestModal;

