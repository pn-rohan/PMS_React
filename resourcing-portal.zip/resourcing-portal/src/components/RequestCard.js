import React from 'react';

const RequestCard = ({ request }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Saved':
        return 'bg-gray-200 text-gray-700';
      case 'Pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'Approved':
        return 'bg-green-100 text-green-700';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-200 text-gray-700';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Saved':
        return '✏️';
      case 'Pending':
        return '⏳';
      case 'Approved':
        return '✓';
      case 'Rejected':
        return '✕';
      default:
        return '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-4">
            <h3 className="text-lg font-medium text-gray-800">{request.title}</h3>
            <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1 ${getStatusColor(request.status)}`}>
              <span>{getStatusIcon(request.status)}</span>
              {request.status}
            </span>
          </div>
          
          <div className="flex items-center gap-6 text-gray-600 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-gray-500">📁</span>
              <span>{request.projects} projects</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-gray-500">👥</span>
              <span>{request.totalResources} total resources</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-gray-500">📅</span>
              <span>{request.date}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-gray-700">
          <span className="text-sm font-medium">{request.requester}</span>
          <span className="text-gray-400">›</span>
        </div>
      </div>
      
      <div className="mt-3 text-xs text-gray-500">
        <span className="font-medium">Requester</span>
      </div>
    </div>
  );
};

export default RequestCard;

